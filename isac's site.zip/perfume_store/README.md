opa professor, tudo bem??

seguindo as orientações pra criação do site, só vou direcionar o senhor pra entender a lógica:
 
como o sr. pediu pra que, por enquanto, apenas o ADM cadastrasse usuário, o login do ADM (admin@perfume.com | admin123) direcionará para a dash, onde o adm vai poder fazer cadastro de usuário no botão superior direito - + adicionar usuário. a ideia é que, no próximo semestre, quando criarmos o index, esses usuários criados sejam direcionado para o index da loja ou site